public class Developer extends Angajat{
    private String task;
    private static final int BONUS = 100;

    public Developer(String name, int yearsOfExperience, int age, double hourlyRate) {
        super(name, yearsOfExperience, age,  hourlyRate);
    }

    public double calculateSalary(int hoursWorked) {
        return (hourlyRate * hoursWorked) + BONUS;
    }

    public void setDevName(){
        this.nume = nume;
    }

    public void resolveTask(String task) {
        this.task = task;
        totalTasksResolved++;
        System.out.println(nume + " resolves task: " + task);
    }
    public String getTask() {
        return task;
    }
}
