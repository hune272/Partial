public class Leader extends Angajat{
    private static final int BONUS = 200;

    public Leader(String name, int yearsOfExperience, int age, double hourlyRate) {
        super(name, yearsOfExperience, age,  hourlyRate);
    }

    public double calculateSalary(int hoursWorked) {
        return (hourlyRate * hoursWorked) + BONUS;
    }

    public void setLeaderName(String nume){
        this.nume = nume;
    }
    public String getLeaderName(){
        return nume;
    }

}
