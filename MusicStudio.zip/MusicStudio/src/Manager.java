public class Manager extends Angajat {
    private static final int BONUS = 300;

    public Manager(String name, int yearsOfExperience, int age, double hourlyRate) {
        super(name, yearsOfExperience, age,  hourlyRate);
    }

    public double calculateSalary(int hoursWorked) {
        return (hourlyRate * hoursWorked) + BONUS;
    }


}
