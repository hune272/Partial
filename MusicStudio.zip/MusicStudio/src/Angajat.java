public abstract class Angajat {
    protected String nume;
    protected int nrAnDeLucru;
    protected int varsta;
    public double hourlyRate;
    protected int totalTasksResolved = 0;

    public Angajat() {

    }

    public Angajat(String nume, int nrAnDeLucru, int varsta, double hourlyRate) {
        this.nume = nume;
        this.nrAnDeLucru = nrAnDeLucru;
        this.varsta = varsta;
        this.hourlyRate = hourlyRate;
    }


    public String getNume() {
         return nume;
     }
     public void setNume(String nume) {
         this.nume = nume;
     }
     public int getVarsta() {
         return varsta;
     }
     public int totalTasksResolved() {
        return totalTasksResolved;
     }
     public void setVarsta(int varsta) {
         this.varsta = varsta;
     }
     public double getWage() {
         return hourlyRate;
     }
     public void setWage(double wage) {
         this.hourlyRate = wage;
     }


    public String getName() {
        return nume;
    }

    public int getTotalTasksResolved() {
        return totalTasksResolved;
    }

    public int getTotalCost(int i) {
        return nrAnDeLucru * i;
    }

}
