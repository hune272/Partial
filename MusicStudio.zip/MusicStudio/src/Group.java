import java.util.ArrayList;
import java.util.List;

public class Group extends Angajat{
    private String groupName;
    private List<Angajat> groupMember = new ArrayList<Angajat>();
    private Leader leader;

    public Group(String groupName, Leader leader){
        this.groupName = groupName;
        this.leader = leader;
    }

    public String getGroupName(){
        return groupName;
    }



    public void addMember(Angajat member) {
        groupMember.add(member);
    }

    public double calculateAllSalary(int hoursWorked){
        double salary = 0;
        for(Angajat member : groupMember){
            salary += calculateAllSalary(hoursWorked);
        }
        return salary;
    }

    public int getTotalTasksResolved() {
        int totalTasks = 0;
        for (Angajat e : groupMember) {
            totalTasks += e.getTotalTasksResolved();
        }
        return totalTasks;
    }
    public Leader getTeamLeader(){
        return leader;
    }
}
