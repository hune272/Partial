import java.util.*;
public class TestStudio {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter total number of employees: ");
        int totalEmployees = sc.nextInt();
        System.out.println("Total number of employees: " + totalEmployees);

        //2 create employees and teams
        Developer dev1 = new Developer("Bob", 25, 3, 30);
        Developer dev2 = new Developer("Rares", 30, 5, 35);
        Developer dev3 = new Developer("Mihai", 28, 4, 32);
        Developer dev4 = new Developer("Ana", 27, 2, 28);
        Leader leader1 = new Leader("Ion", 35, 7, 40);
        Leader leader2 = new Leader("Carmen", 32, 6, 38);
        Manager manager = new Manager("Andrei", 45, 15, 50);
        //3 crearea echipelor
        Group team1 = new Group("Team BackEnd", leader1);
        Group team2 = new Group("Team FrontEnd", leader2);

        team1.addMember(dev1);
        team1.addMember(dev2);
        team1.addMember(leader1);

        team2.addMember(dev3);
        team2.addMember(dev4);
        team2.addMember(leader2);
        //taskurile
        dev3.resolveTask("Task 1");
        dev3.resolveTask("Task 2");
        dev3.resolveTask("Task 3");
        dev2.resolveTask("Task 4");
        dev1.resolveTask("Task 5");

        //afisarea primii doi angajati
        List<Angajat> angajati = Arrays.asList(dev1, dev2, dev3, dev4);
        angajati.sort((e1, e2) -> Integer.compare(e2.getTotalTasksResolved(), e1.getTotalTasksResolved()));
        System.out.println("Top 2 task resolvers:");
        for (
                int i = 0;
                i < 2 && i < angajati.size(); i++) {
            System.out.println(angajati.get(i).getName() + " resolved task " + angajati.get(i).getTotalTasksResolved());
        }

        List<Angajat> teams = Arrays.asList(team1, team2);
        teams.sort((t1, t2) -> Integer.compare(t2.getTotalTasksResolved(), t1.getTotalTasksResolved()));
        System.out.println("Teams by efficiency:");
        for (
                Angajat t : teams) {
            System.out.println("Team: " + t.getName() + ", Leader: " + t.getName() +
                    ", Total Cost: " + t.getTotalCost(160) + ", Total Tasks: " + t.getTotalTasksResolved());
        }
    }
}


